USE [BDALM2020GPWARI]
GO

CREATE TABLE [dbo].[tb_TareaSistema_c](
	[IdTareaSistema] [INT] IDENTITY(1,1) PRIMARY KEY,
	[Are_Codigo] [varchar](6) NULL,
	[IdClaseMantenimiento] [varchar](50) NULL,
	[Operacion] [varchar] (50) NULL
) ON [PRIMARY]
GO


CREATE TABLE [dbo].[tb_TareaSistema_d](
	[IdTareaSistema] [int] NOT NULL,
	[IdTarea] [int] NOT NULL,
	[Activo] [bit] NULL
) ON [PRIMARY]
GO

