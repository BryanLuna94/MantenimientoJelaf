CREATE PROCEDURE proc_ObtenerEncabezadoPreventivo
(  
 @Are_Codigo  VARCHAR(06),
 @Codigo_Programacion_Real VARCHAR(15)
)  
AS  
SET NOCOUNT ON;  
BEGIN  
	select DISTINCT 
		a.Are_Codigo,
		a.Are_Nombre, --PLACA
		b.Ben_Nombre, -- CHOFER
		t.Tbg_Descripcion,

		t.Tbg_Descripcion as Modelo,
		Kmt_Viaje as Kilometraje, 
		Fech_Programacion FechaViaje,
		iif((select IdInforme from tb_Informe (nolock) where Are_Codigo = a.Are_Codigo) is null,'',(select IdInforme from tb_Informe where Are_Codigo = a.Are_Codigo)) as OrdenTrabajo,
		a.MARC_BUS as Marca,
		'' as Ubicacion,
		p.CODI_PROGRAMACION_REAL
	from Are a (nolock)
		inner join PROGRAMACION p (nolock) on p.CODI_BUS = a.Are_Codigo  
		inner join Ben b (nolock) on b.Ben_Codigo = p.CODI_CHOFER
		inner join tbg t (nolock) on t.Tbg_Codigo = a.Tipo_UnidadId and  t.tbg_tabla='28'
	where a.Are_Codigo =@Are_Codigo and p.CODI_PROGRAMACION_REAL = @Codigo_Programacion_Real
END  

