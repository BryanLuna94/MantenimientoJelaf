CREATE PROCEDURE proc_Tbg_ObtenerMaestras
(  
 @Tbg_Tabla  VARCHAR(06),  
 @Tbg_Codigo VARCHAR(06)  = ''
)  
AS  
SET NOCOUNT ON;  
BEGIN  
  SELECT Tbg_Codigo,Tbg_Descripcion  FROM Tbg (NOLOCK) 
  WHERE (@Tbg_Tabla  = '' OR Tbg_Tabla  = @Tbg_Tabla)  
    AND (@Tbg_Codigo = '' OR Tbg_Codigo = @Tbg_Codigo);  
END  