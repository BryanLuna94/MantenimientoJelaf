CREATE PROCEDURE proc_InsertarTareaSistema
(  
 @Are_Codigo  VARCHAR(06),
 @IdClaseMantenimiento VARCHAR(50),
 @Operacion VARCHAR (50) ,
 @XMLData XML
)  
AS  
SET NOCOUNT ON;  
BEGIN  
	DECLARE @IdTareaSistema INT
	DECLARE @EXISTE INT = 0

	SET @EXISTE = (SELECT IdTareaSistema FROM [tb_TareaSistema_c] WHERE Are_Codigo = @Are_Codigo AND IdClaseMantenimiento = @IdClaseMantenimiento)

	IF @EXISTE > 0 
		BEGIN
			SET @IdTareaSistema = @EXISTE
			UPDATE [tb_TareaSistema_c] SET Operacion = @Operacion WHERE IdTareaSistema = @IdTareaSistema
			DELETE FROM [tb_TareaSistema_d] WHERE IdTareaSistema = @IdTareaSistema
		END
	ELSE
		BEGIN
			INSERT INTO [tb_TareaSistema_c] (Are_Codigo,IdClaseMantenimiento,Operacion) VALUES (@Are_Codigo,@IdClaseMantenimiento,@Operacion)
			SET @IdTareaSistema = SCOPE_IDENTITY();
		END


	DECLARE @Temp AS TABLE
	(
		[IdTarea] [int] NOT NULL
	) 
	INSERT INTO @Temp
	(
	IdTarea
	)
	SELECT
	t.c.value('@IdTarea','int')
	FROM @XMLData.nodes('Root/Tareas') as t(c)

	INSERT INTO [tb_TareaSistema_d] (IdTareaSistema,IdTarea,Activo) 
	SELECT @IdTareaSistema, IdTarea, 1 FROM @Temp

END  

