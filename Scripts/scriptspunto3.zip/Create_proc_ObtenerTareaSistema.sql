
CREATE PROCEDURE proc_ObtenerTareaSistema
(  
 @Are_Codigo  VARCHAR(06),
 @IdClaseMantenimiento VARCHAR(50)
)  
AS  
SET NOCOUNT ON;  
BEGIN  

	select distinct  
		t.IdTarea,
		t.Descripcion as Tarea_Description,
		sm.ID_tb_Sistema_Mant,
		sm.Descripcion as Sistema_Descripcion
		,IIF(tsd.Activo IS NULL, 0, tsd.Activo) as Activo,
		tsc.Operacion
	from 
		 [tb_TareaSistema_c] tsc (nolock) 
		 inner join [tb_TareaSistema_d] tsd (nolock) on tsc.IdTareaSistema = tsd.IdTareaSistema
		 right join Tb_Tareas t (nolock) on tsd.IdTarea = t.IdTarea
		 inner join tb_TipoMantenimiento tm (nolock) on t.IdTipMan = tm.IdTipMan
		 inner join tb_claseMantenimiento c (nolock) on c.Descripcion = tm.Descripcion and tm.FlgMov='1'
		 inner join Are a (nolock) on a.MARC_BUS=tm.Cod_Marca and a.MODE_BUS = tm.cod_Modelo
		 inner join tb_Sistema_Mant sm (nolock) on sm.ID_tb_Sistema_Mant = t.ID_tb_Sistema_Mant
		 inner join tb_SubSistema_Mant ssm (nolock) on ssm.ID_tb_Sistema_Mant = sm.ID_tb_Sistema_Mant

	where 
	a.Are_Codigo = @Are_Codigo and tm.Descripcion = @IdClaseMantenimiento
	ORDER BY sm.Descripcion,T.IdTarea
	
END  



